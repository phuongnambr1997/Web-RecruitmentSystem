package com.jobs.recruitment.model;

public class JobSeeker {

}
