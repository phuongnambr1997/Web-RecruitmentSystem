package com.jobs.recruitment.service;

import com.jobs.recruitment.model.JobPost;

public interface JobService {
	public abstract boolean newJob(JobPost jobPost);

}
